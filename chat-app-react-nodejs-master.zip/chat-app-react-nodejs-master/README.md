# Steps to Start the App

## Install the Public Dependencies
## Install the Server Dependencies
## In the Server Directory there's a .env file. Change the value of mongodb inside the file. Set the value as your mongodb connection url.
## Now start the server by yarn start
## Now start the react by yarn start
## And the chat application would be running successfully by now.
